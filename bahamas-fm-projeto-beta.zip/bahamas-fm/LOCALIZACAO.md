# Busca local do Bahamas FM

O catálogo agora aceita filtros separados para:
- país
- estado
- cidade
- texto livre (rádio, artista, gênero ou frequência)

A localização automática será usada somente após autorização do ouvinte. Se a pessoa não autorizar, poderá escolher manualmente qualquer estado e cidade.
