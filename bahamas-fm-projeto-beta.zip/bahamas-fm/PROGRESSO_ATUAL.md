# Bahamas FM — progresso atual

A beta agora salva favoritos automaticamente no aparelho e registra o histórico das rádios escolhidas. Isso evita perder os dados ao fechar o aplicativo.

Próxima implementação: filtros de estado/cidade e localização automática na busca.
