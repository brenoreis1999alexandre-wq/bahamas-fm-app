# Bahamas FM — preparação da beta

- [x] Pesquisa remota de rádios
- [x] Filtro inicial de rádios brasileiras
- [x] Player ExoPlayer para stream ao vivo
- [x] Botões de rádio anterior/próxima na interface
- [x] Favoritos na interface
- [x] Estrutura de localização
- [ ] Exibir nome da rádio remota no mini-player
- [ ] Persistir favoritos e histórico
- [ ] Cadastro e login
- [ ] Testar streams instáveis e reconexão
- [ ] Gerar APK assinado
