# Painel do proprietário — Bahamas FM

## Funções planejadas
- Login exclusivo do proprietário
- Adicionar rádio por nome, URL do stream, logo, gênero, país, estado e cidade
- Editar ou remover rádio
- Destacar rádios Hunter
- Aprovar sugestões de ouvintes
- Ocultar categorias não desejadas
- Ver rádios mais ouvidas
- Organizar Descubra, Em alta e Recomendações
- Enviar avisos aos ouvintes

## Comando futuro com IA
"Adicione a Rádio X, de Janaúba, gênero pisadinha, stream URL Y."

A IA deverá validar os dados, testar o stream e enviar para aprovação antes de publicar.
