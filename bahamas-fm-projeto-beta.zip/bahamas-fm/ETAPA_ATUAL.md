# Etapa atual — persistência local

A beta agora tem uma camada preparada para guardar no celular:
- rádios favoritas
- histórico das últimas 30 rádios ouvidas

Esta camada será ligada à conta do usuário quando o cadastro e o banco online forem implementados, para sincronizar favoritos entre aparelhos.
