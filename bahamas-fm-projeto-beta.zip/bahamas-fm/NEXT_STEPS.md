# Bahamas FM — progresso

## Já preparado
- Base Android com identidade Bahamas FM
- Navegação inicial e player visual
- Pesquisa local por rádio, gênero, cidade e frequência
- Favoritos e perfil inicial
- Dependência de player de áudio para streams ao vivo
- Conector inicial para catálogo público Radio Browser, com filtro Brasil e ocultação de rádios quebradas

## Próxima etapa
- Integrar o catálogo ao app com carregamento assíncrono
- Filtros de estado/cidade e localização do usuário
- Validar streams antes de exibir
- Cadastro, banco de dados e painel do proprietário

A categoria gospel permanece excluída do catálogo do Bahamas FM.
