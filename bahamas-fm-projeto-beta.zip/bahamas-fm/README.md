# Bahamas FM
Primeiro protótipo Android do aplicativo de rádios.

## Próximas etapas
- player real e catálogo de rádios
- busca por rádio, artista, frequência, gênero, estado e cidade
- localização automática
- cadastro e perfil
- favoritos, histórico e recomendações
- painel administrativo
- reconhecimento de músicas e letras

A categoria gospel está excluída do produto.
