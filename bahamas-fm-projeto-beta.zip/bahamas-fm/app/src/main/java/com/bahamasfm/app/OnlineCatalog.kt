package com.bahamasfm.app

import android.util.Base64
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Catálogo remoto do Bahamas FM. Pode ser alterado sem publicar uma nova versão do app. */
object OnlineCatalog {
    private const val CATALOG_ENDPOINT = "https://api.github.com/repos/brenoreis1999alexandre-wq/bahamas-fm-catalog/contents/radios.json"
    fun load(): List<CatalogRadio> {
        val connection = URL(CATALOG_ENDPOINT).openConnection() as HttpURLConnection
        connection.setRequestProperty("Accept", "application/vnd.github+json")
        connection.setRequestProperty("User-Agent", "Bahamas-FM-Android")
        connection.connectTimeout = 8000; connection.readTimeout = 8000
        return try {
            val envelope = JSONObject(connection.inputStream.bufferedReader().use { it.readText() })
            val content = Base64.decode(envelope.getString("content").replace("\\n", ""), Base64.DEFAULT).toString(Charsets.UTF_8)
            val catalog = JSONObject(content); val array = catalog.optJSONArray("stations") ?: return emptyList()
            buildList { for (i in 0 until array.length()) { val r = array.getJSONObject(i); if (!r.optBoolean("blocked", false) && !r.optString("genre").equals("gospel", true)) add(CatalogRadio(r.optString("name"), r.optString("streamUrl"), r.optString("genre"), r.optString("city"), r.optString("state"), r.optString("country", "Brasil"), r.optString("logoUrl"))) } }
        } finally { connection.disconnect() }
    }
}
