package com.bahamasfm.app

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Catálogo remoto do Bahamas FM, sem depender do limite da API do GitHub. */
object OnlineCatalog {
    private const val CATALOG_ENDPOINT = "https://raw.githubusercontent.com/brenoreis1999alexandre-wq/bahamas-fm-catalog/main/radios.json"

    fun load(): List<CatalogRadio> {
        val connection = URL(CATALOG_ENDPOINT).openConnection() as HttpURLConnection
        connection.setRequestProperty("User-Agent", "Bahamas-FM-Android")
        connection.connectTimeout = 8000
        connection.readTimeout = 8000
        return try {
            val content = connection.inputStream.bufferedReader().use { it.readText() }
            val array = JSONObject(content).optJSONArray("stations") ?: return emptyList()
            buildList {
                for (i in 0 until array.length()) {
                    val r = array.getJSONObject(i)
                    val genre = r.optString("genre")
                    if (!r.optBoolean("blocked", false) && !genre.equals("gospel", true)) {
                        add(CatalogRadio(r.optString("name"), r.optString("streamUrl"), genre, r.optString("city"), r.optString("state"), r.optString("country", "Brasil"), r.optString("logoUrl")))
                    }
                }
            }
        } finally {
            connection.disconnect()
        }
    }
}
