package com.bahamasfm.app

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.Image
import androidx.compose.ui.draw.clip
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import coil.compose.AsyncImage
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Composable
fun RemoteCatalogScreen(radios: List<CatalogRadio>, query: String, onQuery: (String) -> Unit, country: String, onCountry: (String) -> Unit, state: String, onState: (String) -> Unit, city: String, onCity: (String) -> Unit, onPlay: (CatalogRadio) -> Unit) {
    Text("Pesquisar", color = Color.White, fontSize = androidx.compose.ui.unit.TextUnit(25f, androidx.compose.ui.unit.TextUnitType.Sp), fontWeight = androidx.compose.ui.text.font.FontWeight.Bold, modifier = Modifier.padding(top = 24.dp, bottom = 12.dp))
    OutlinedTextField(value = query, onValueChange = onQuery, modifier = Modifier.fillMaxWidth(), placeholder = { Text("Rádio, gênero, cidade ou frequência") }, singleLine = true)
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) { RegionPicker("🌎 País", country, listOf("🇧🇷 Brasil", "🌎 Mundo"), onCountry, Modifier.weight(1f)); RegionPicker("📍 Estado", state, BrazilRegions.states, onState, Modifier.weight(1f)) }
    RegionPicker("🏙️ Cidade", city, (BrazilRegions.featuredCities[state] ?: BrazilRegions.featuredCities.values.flatten().distinct()), onCity, Modifier.fillMaxWidth().padding(top = 8.dp))
    if (radios.isEmpty()) Text("Nenhuma rádio encontrada. Tente outro filtro.", color = Color.LightGray, modifier = Modifier.padding(top = 16.dp))
    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(vertical = 16.dp)) {
        items(radios) { radio ->
            val station = Station(radio.name, radio.genre.ifBlank { "Rádio" }, radio.city.ifBlank { radio.country }, "", Color(0xFF23D6D0), radio.streamUrl, radio.favicon)
            StationRow(station, { onPlay(radio) }, androidx.compose.runtime.mutableStateListOf())
        }
    }
}

@Composable
private fun RegionPicker(label: String, value: String, options: List<String>, onSelected: (String) -> Unit, modifier: Modifier) {
    var expanded by remember { mutableStateOf(false) }
    Box(modifier.clip(RoundedCornerShape(14.dp)).background(Color(0xFF102B40)).clickable { expanded = true }.padding(horizontal = 14.dp, vertical = 16.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(if (value.isBlank()) label else value, color = if (value.isBlank()) Color.LightGray else Color.White, modifier = Modifier.weight(1f), maxLines = 1)
            Icon(Icons.Default.KeyboardArrowDown, "Abrir opções", tint = Color(0xFF23D6D0))
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) { options.forEach { option -> DropdownMenuItem(text = { Text(option) }, onClick = { onSelected(option); expanded = false }) } }
    }
}

@Composable
fun RemoteHome(radios: List<CatalogRadio>, onPlay: (CatalogRadio) -> Unit, onMore: () -> Unit, onArtist: () -> Unit) {
    Text("Olá, Breno", color = Color.White, fontSize = androidx.compose.ui.unit.TextUnit(25f, androidx.compose.ui.unit.TextUnitType.Sp), fontWeight = androidx.compose.ui.text.font.FontWeight.Bold, modifier = Modifier.padding(top = 24.dp))
    Text("Rádios perto de você", color = Color.LightGray)
    if (radios.isEmpty()) {
        Text("Carregando rádios reais...", color = Color.LightGray, modifier = Modifier.padding(top = 20.dp))
    } else {
        RemoteSection("Continue ouvindo", radios.take(6), onPlay, onMore)
        RemoteDiscoverSection(onMore, onArtist)
        RemoteSection("Pagode e Samba", radios.filter { it.genre.contains("pagode", true) || it.genre.contains("samba", true) }, onPlay, onMore)
        RemoteSection("Forró e Pisadinha", radios.filter { it.genre.contains("forró", true) || it.genre.contains("pisadinha", true) }, onPlay, onMore)
        RemoteSection("Sertanejo", radios.filter { it.genre.contains("sertanej", true) }, onPlay, onMore)
        RemoteSection("Pop e Rock", radios.filter { it.genre.contains("pop", true) || it.genre.contains("rock", true) }, onPlay, onMore)
        RemoteSection("Rádios em alta", radios.take(12), onPlay, onMore)
        RemoteSection("Perto de você", radios.take(12), onPlay, onMore)
    }
}

@Composable
private fun RemoteSection(title: String, radios: List<CatalogRadio>, onPlay: (CatalogRadio) -> Unit, onMore: () -> Unit) {
    if (title.isNotBlank()) Row(Modifier.fillMaxWidth().padding(top = 22.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) { Text(title, color = Color.White, fontSize = androidx.compose.ui.unit.TextUnit(19f, androidx.compose.ui.unit.TextUnitType.Sp), fontWeight = androidx.compose.ui.text.font.FontWeight.Bold, modifier = Modifier.weight(1f)); TextButton(onClick = onMore) { Text("Ver mais", color = Color(0xFF23D6D0)) } }
    LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) { items(radios) { radio ->
        Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF23D6D0)), modifier = Modifier.width(150.dp).height(138.dp).clickable { onPlay(radio) }) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.SpaceBetween) {
                if (radio.favicon.isNotBlank()) AsyncImage(model = radio.favicon, contentDescription = radio.name, modifier = Modifier.size(38.dp).clip(RoundedCornerShape(10.dp))) else Icon(Icons.Default.GraphicEq, null, tint = Color(0xFF071A2B), modifier = Modifier.size(30.dp))
                Text(radio.name, color = Color(0xFF071A2B), fontWeight = androidx.compose.ui.text.font.FontWeight.Bold, maxLines = 2)
                Text(radio.genre.ifBlank { "Rádio ao vivo" }, color = Color(0xFF071A2B), fontSize = androidx.compose.ui.unit.TextUnit(12f, androidx.compose.ui.unit.TextUnitType.Sp), maxLines = 1)
                Icon(Icons.Default.PlayCircle, "Tocar", tint = Color(0xFF071A2B), modifier = Modifier.size(28.dp))
            }
        }
    } }
}

@Composable
private fun RemoteDiscoverSection(onExplore: () -> Unit, onArtist: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(top = 22.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) { Text("Descubra", color = Color.White, fontSize = androidx.compose.ui.unit.TextUnit(19f, androidx.compose.ui.unit.TextUnitType.Sp), fontWeight = androidx.compose.ui.text.font.FontWeight.Bold, modifier = Modifier.weight(1f)); TextButton(onClick = onExplore) { Text("Ver mais", color = Color(0xFF23D6D0)) } }
    LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF23D6D0)), modifier = Modifier.width(170.dp).height(120.dp).clickable { onExplore() }) { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.SpaceBetween) { Icon(Icons.Default.Explore, null, tint = Color(0xFF071A2B)); Text("Explorar rádios", color = Color(0xFF071A2B), fontWeight = androidx.compose.ui.text.font.FontWeight.Bold); Text("Todas as rádios", color = Color(0xFF071A2B)) } } }
        item { Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFFFF6B5E)), modifier = Modifier.width(170.dp).height(120.dp).clickable { onArtist() }) { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.SpaceBetween) { Icon(Icons.Default.PersonSearch, null, tint = Color(0xFF071A2B)); Text("Buscar artista", color = Color(0xFF071A2B), fontWeight = androidx.compose.ui.text.font.FontWeight.Bold); Text("Encontre onde toca", color = Color(0xFF071A2B)) } } }
    }
}
