package com.bahamasfm.app

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.clickable
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.Image
import androidx.compose.ui.draw.clip
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import coil.compose.AsyncImage
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Composable
fun RemoteCatalogScreen(radios: List<CatalogRadio>, query: String, onQuery: (String) -> Unit, country: String, onCountry: (String) -> Unit, state: String, onState: (String) -> Unit, city: String, onCity: (String) -> Unit, onPlay: (CatalogRadio) -> Unit) {
    Text("Pesquisar", color = Color.White, fontSize = androidx.compose.ui.unit.TextUnit(25f, androidx.compose.ui.unit.TextUnitType.Sp), fontWeight = androidx.compose.ui.text.font.FontWeight.Bold, modifier = Modifier.padding(top = 24.dp, bottom = 12.dp))
    OutlinedTextField(value = query, onValueChange = onQuery, modifier = Modifier.fillMaxWidth(), placeholder = { Text("Rádio, gênero, cidade ou frequência") }, singleLine = true)
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) { RegionPicker("🌎 País", country, listOf("🇧🇷 Brasil", "🌎 Mundo"), onCountry, Modifier.weight(1f)); RegionPicker("📍 Estado", state, BrazilRegions.states, onState, Modifier.weight(1f)) }
    RegionPicker("🏙️ Cidade", city, (BrazilRegions.featuredCities[state] ?: BrazilRegions.featuredCities.values.flatten().distinct()), onCity, Modifier.fillMaxWidth().padding(top = 8.dp))
    if (radios.isEmpty()) Text("Nenhuma rádio encontrada. Tente outro filtro.", color = Color.LightGray, modifier = Modifier.padding(top = 16.dp))
    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(vertical = 16.dp)) {
        items(radios) { radio ->
            val station = Station(radio.name, radio.genre.ifBlank { "Rádio" }, radio.city.ifBlank { radio.country }, "", Color(0xFF23D6D0), radio.streamUrl, radio.favicon)
            StationRow(station, { onPlay(radio) }, androidx.compose.runtime.mutableStateListOf())
        }
    }
}

@Composable
private fun RegionPicker(label: String, value: String, options: List<String>, onSelected: (String) -> Unit, modifier: Modifier) {
    var expanded by remember { mutableStateOf(false) }
    Box(modifier) {
        OutlinedTextField(value = value, onValueChange = {}, readOnly = true, modifier = Modifier.fillMaxWidth().clickable { expanded = true }, placeholder = { Text(label) }, singleLine = true)
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) { options.forEach { option -> DropdownMenuItem(text = { Text(option) }, onClick = { onSelected(option); expanded = false }) } }
    }
}

@Composable
fun RemoteHome(radios: List<CatalogRadio>, onPlay: (CatalogRadio) -> Unit) {
    Text("Olá, Breno", color = Color.White, fontSize = androidx.compose.ui.unit.TextUnit(25f, androidx.compose.ui.unit.TextUnitType.Sp), fontWeight = androidx.compose.ui.text.font.FontWeight.Bold, modifier = Modifier.padding(top = 24.dp))
    Text("Rádios perto de você", color = Color.LightGray)
    if (radios.isEmpty()) {
        Text("Carregando rádios reais...", color = Color.LightGray, modifier = Modifier.padding(top = 20.dp))
    } else {
        RemoteSection("Continue ouvindo", radios.take(6), onPlay)
        Text("Descubra", color = Color.White, fontSize = androidx.compose.ui.unit.TextUnit(19f, androidx.compose.ui.unit.TextUnitType.Sp), fontWeight = androidx.compose.ui.text.font.FontWeight.Bold, modifier = Modifier.padding(top = 22.dp, bottom = 10.dp))
        RemoteSection("", radios.drop(6).take(8), onPlay)
        RemoteSection("Rádios em alta", radios.take(12), onPlay)
        RemoteSection("Perto de você", radios.take(12), onPlay)
    }
}

@Composable
private fun RemoteSection(title: String, radios: List<CatalogRadio>, onPlay: (CatalogRadio) -> Unit) {
    if (title.isNotBlank()) Text(title, color = Color.White, fontSize = androidx.compose.ui.unit.TextUnit(19f, androidx.compose.ui.unit.TextUnitType.Sp), fontWeight = androidx.compose.ui.text.font.FontWeight.Bold, modifier = Modifier.padding(top = 22.dp, bottom = 10.dp))
    LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) { items(radios) { radio ->
        Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF23D6D0)), modifier = Modifier.width(150.dp).height(138.dp).clickable { onPlay(radio) }) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.SpaceBetween) {
                if (radio.favicon.isNotBlank()) AsyncImage(model = radio.favicon, contentDescription = radio.name, modifier = Modifier.size(38.dp).clip(RoundedCornerShape(10.dp))) else Icon(Icons.Default.GraphicEq, null, tint = Color(0xFF071A2B), modifier = Modifier.size(30.dp))
                Text(radio.name, color = Color(0xFF071A2B), fontWeight = androidx.compose.ui.text.font.FontWeight.Bold, maxLines = 2)
                Text(radio.genre.ifBlank { "Rádio ao vivo" }, color = Color(0xFF071A2B), fontSize = androidx.compose.ui.unit.TextUnit(12f, androidx.compose.ui.unit.TextUnitType.Sp), maxLines = 1)
                Icon(Icons.Default.PlayCircle, "Tocar", tint = Color(0xFF071A2B), modifier = Modifier.size(28.dp))
            }
        }
    } }
}
