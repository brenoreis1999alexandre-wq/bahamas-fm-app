package com.bahamasfm.app

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.clickable
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Composable
fun RemoteCatalogScreen(radios: List<CatalogRadio>, query: String, onQuery: (String) -> Unit, country: String, onCountry: (String) -> Unit, state: String, onState: (String) -> Unit, city: String, onCity: (String) -> Unit, onPlay: (CatalogRadio) -> Unit) {
    Text("Pesquisar", color = Color.White, fontSize = androidx.compose.ui.unit.TextUnit(25f, androidx.compose.ui.unit.TextUnitType.Sp), fontWeight = androidx.compose.ui.text.font.FontWeight.Bold, modifier = Modifier.padding(top = 24.dp, bottom = 12.dp))
    OutlinedTextField(value = query, onValueChange = onQuery, modifier = Modifier.fillMaxWidth(), placeholder = { Text("Rádio, gênero, cidade ou frequência") }, singleLine = true)
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) { RegionPicker("País", country, listOf("Brasil", "Mundo"), onCountry, Modifier.weight(1f)); RegionPicker("Estado", state, BrazilRegions.states, onState, Modifier.weight(1f)) }
    RegionPicker("Cidade", city, (BrazilRegions.featuredCities[state] ?: emptyList()), onCity, Modifier.fillMaxWidth().padding(top = 8.dp))
    if (radios.isEmpty()) Text("Nenhuma rádio encontrada. Tente outro filtro.", color = Color.LightGray, modifier = Modifier.padding(top = 16.dp))
    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(vertical = 16.dp)) {
        items(radios) { radio ->
            val station = Station(radio.name, radio.genre.ifBlank { "Rádio" }, radio.city.ifBlank { radio.country }, "", Color(0xFF23D6D0))
            StationRow(station, { onPlay(radio) }, androidx.compose.runtime.mutableStateListOf())
        }
    }
}

@Composable
private fun RegionPicker(label: String, value: String, options: List<String>, onSelected: (String) -> Unit, modifier: Modifier) {
    var expanded by remember { mutableStateOf(false) }
    Box(modifier) {
        OutlinedTextField(value = value, onValueChange = {}, readOnly = true, modifier = Modifier.fillMaxWidth().clickable { expanded = true }, placeholder = { Text(label) }, singleLine = true)
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) { options.forEach { option -> DropdownMenuItem(text = { Text(option) }, onClick = { onSelected(option); expanded = false }) } }
    }
}
