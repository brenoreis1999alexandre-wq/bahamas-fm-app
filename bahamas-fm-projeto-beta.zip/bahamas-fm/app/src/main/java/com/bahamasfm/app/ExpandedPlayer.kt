package com.bahamasfm.app

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage

private val PlayerNavy = Color(0xFF071A2B)
private val PlayerTurquoise = Color(0xFF23D6D0)
private val PlayerCoral = Color(0xFFFF6B5E)

@Composable
fun ExpandedPlayer(radio: CatalogRadio, playing: Boolean, onToggle: () -> Unit, favorite: Boolean, onFavorite: () -> Unit, onClose: () -> Unit, onPrevious: () -> Unit, onNext: () -> Unit) {
    Surface(Modifier.fillMaxSize(), color = PlayerNavy) {
        Column(Modifier.fillMaxSize().padding(horizontal = 22.dp, vertical = 18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onClose) { Icon(Icons.Default.Close, "Fechar", tint = Color.White) }
                Text("TOCANDO AGORA • BAHAMAS FM", color = Color.LightGray, fontSize = 12.sp, modifier = Modifier.weight(1f))
                IconButton(onClick = onFavorite) { Icon(if (favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, "Favoritar", tint = PlayerCoral) }
            }
            Spacer(Modifier.height(20.dp))
            Box(Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(28.dp)).background(Color(0xFF102B40)), contentAlignment = Alignment.Center) {
                if (radio.favicon.isNotBlank()) AsyncImage(model = radio.favicon, contentDescription = radio.name, modifier = Modifier.fillMaxSize().padding(28.dp).clip(RoundedCornerShape(22.dp))) else Icon(Icons.Default.GraphicEq, null, tint = PlayerTurquoise, modifier = Modifier.size(120.dp))
            }
            Text(radio.name, color = Color.White, fontSize = 25.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold, modifier = Modifier.padding(top = 24.dp))
            Text("${radio.country} • ${radio.genre.ifBlank { "Rádio ao vivo" }}", color = Color.LightGray, modifier = Modifier.padding(top = 8.dp))
            Text("AO VIVO", color = PlayerTurquoise, fontSize = 12.sp, modifier = Modifier.padding(top = 28.dp))
            Spacer(Modifier.weight(1f))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(28.dp)) {
                IconButton(onClick = onPrevious, modifier = Modifier.size(58.dp).background(Color(0xFF263746), RoundedCornerShape(50))) { Icon(Icons.Default.SkipPrevious, "Anterior", tint = Color.White) }
                IconButton(onClick = onToggle, modifier = Modifier.size(82.dp).background(Color.White, RoundedCornerShape(50))) { Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, "Reproduzir", tint = PlayerNavy, modifier = Modifier.size(42.dp)) }
                IconButton(onClick = onNext, modifier = Modifier.size(58.dp).background(Color(0xFF263746), RoundedCornerShape(50))) { Icon(Icons.Default.SkipNext, "Próxima", tint = Color.White) }
            }
            Spacer(Modifier.height(28.dp))
        }
    }
}
