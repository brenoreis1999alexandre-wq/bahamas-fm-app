package com.bahamasfm.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.Image
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.draw.clip
import coil.compose.AsyncImage

private val Navy = Color(0xFF071A2B); private val Turquoise = Color(0xFF23D6D0); private val Coral = Color(0xFFFF6B5E); private val Gold = Color(0xFFFFC857)
data class Station(val name: String, val genre: String, val city: String, val frequency: String, val color: Color, val streamUrl: String = "", val logoUrl: String = "")
private val stations = listOf(
    Station("Hunter Pagode", "Pagode", "Brasil", "", Coral),
    Station("Montes Claros FM", "Local", "Montes Claros, MG", "98.9", Turquoise),
    Station("Piseiro Brasil", "Pisadinha", "Brasil", "", Gold),
    Station("Rock Station", "Rock", "Mundo", "104.1", Color(0xFF8067D8)),
    Station("Sertanejo Brasil", "Sertanejo", "Brasil", "", Color(0xFFED9B40))
)

class MainActivity : ComponentActivity() { override fun onCreate(state: Bundle?) { super.onCreate(state); setContent { BahamasApp() } } }

@Composable fun BahamasApp() {
    val context = LocalContext.current; val preferences = remember { UserPreferences(context) }; val radioPlayer = remember { RadioPlayer(context) }; DisposableEffect(Unit) { onDispose { radioPlayer.release() } }; val catalog: CatalogViewModel = viewModel(); val remoteRadios by catalog.radios.collectAsState(); var tab by remember { mutableStateOf(0) }; var playing by remember { mutableStateOf(0) }; var search by remember { mutableStateOf("") }; var countryFilter by remember { mutableStateOf("Brasil") }; var stateFilter by remember { mutableStateOf("") }; var cityFilter by remember { mutableStateOf("") }; var remoteTitle by remember { mutableStateOf<String?>(null) }; var remoteGenre by remember { mutableStateOf<String?>(null) }; var isPlaying by remember { mutableStateOf(false) }; var currentRemote by remember { mutableStateOf<CatalogRadio?>(null) }; var remoteIndex by remember { mutableStateOf(0) }; var loggedIn by remember { mutableStateOf(false) }; val favorites = remember { mutableStateListOf<String>().apply { addAll(preferences.favorites()) } }; LaunchedEffect(favorites.toList()) { preferences.saveFavorites(favorites.toSet()) }
    val current = stations[playing]
    LaunchedEffect(Unit) { catalog.search("", countryCode = "BR") }
    LaunchedEffect(tab, search, stateFilter, cityFilter) { if (tab == 1) catalog.search(search, countryCode = if (countryFilter == "Brasil") "BR" else "", state = stateFilter, city = cityFilter) }
    MaterialTheme(colorScheme = darkColorScheme(primary = Turquoise, background = Navy, surface = Color(0xFF102B40))) {
        Scaffold(containerColor = Navy, bottomBar = { Column { MiniPlayer(current, isPlaying, { if (isPlaying) { radioPlayer.pause(); isPlaying = false } else { currentRemote?.let { radioPlayer.play(it.streamUrl) }; isPlaying = true } }, remoteTitle, remoteGenre, { if (remoteRadios.isNotEmpty()) { remoteIndex = (remoteIndex + remoteRadios.size - 1) % remoteRadios.size; val radio = remoteRadios[remoteIndex]; currentRemote = radio; remoteTitle = radio.name; remoteGenre = radio.genre; radioPlayer.play(radio.streamUrl); isPlaying = true } }, { if (remoteRadios.isNotEmpty()) { remoteIndex = (remoteIndex + 1) % remoteRadios.size; val radio = remoteRadios[remoteIndex]; currentRemote = radio; remoteTitle = radio.name; remoteGenre = radio.genre; radioPlayer.play(radio.streamUrl); isPlaying = true } }); NavigationBar(containerColor = Color(0xFF0B2338)) { val nav = listOf(Icons.Default.Home to "Início", Icons.Default.Search to "Pesquisar", Icons.Default.Favorite to "Favoritos", Icons.Default.Person to "Perfil"); nav.forEachIndexed { i, item -> NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Icon(item.first, null) }, label = { Text(item.second) }) } } } }) { pad ->
            Column(Modifier.padding(pad).padding(horizontal = 18.dp).fillMaxSize().then(if (tab == 0) Modifier.verticalScroll(rememberScrollState()) else Modifier)) {
                BrandHeader()
                when (tab) {
                    0 -> RemoteHome(remoteRadios, { radio -> remoteIndex = remoteRadios.indexOf(radio).coerceAtLeast(0); currentRemote = radio; radioPlayer.play(radio.streamUrl); preferences.addHistory(radio.name); remoteTitle = radio.name; remoteGenre = radio.genre.ifBlank { radio.country }; isPlaying = true })
                    1 -> RemoteCatalogScreen(remoteRadios, search, { search = it }, countryFilter, { countryFilter = it }, stateFilter, { stateFilter = it }, cityFilter, { cityFilter = it }, { radio -> remoteIndex = remoteRadios.indexOf(radio).coerceAtLeast(0); currentRemote = radio; radioPlayer.play(radio.streamUrl); preferences.addHistory(radio.name); remoteTitle = radio.name; remoteGenre = radio.genre.ifBlank { radio.country }; isPlaying = true })
                    2 -> SearchScreen("", {}, stations.filter { favorites.contains(it.name) }, { playing = stations.indexOf(it); isPlaying = true }, favorites, "Favoritos")
                    else -> Profile(loggedIn) { loggedIn = true }
                }
            }
        }
    }
}

@Composable fun BrandHeader() { Row(Modifier.fillMaxWidth().padding(top = 16.dp), verticalAlignment = Alignment.CenterVertically) { Image(painterResource(com.bahamasfm.app.R.drawable.bahamas_fm_logo), "Logomarca Bahamas FM", modifier = Modifier.size(58.dp)); Spacer(Modifier.width(10.dp)); Text("Bahamas FM", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold) } }
@Composable fun Home(playing: Int, onPlay: (Int) -> Unit, favorites: MutableList<String>) { Text("Olá, Breno", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 24.dp)); Text("Rádios perto de você", color = Color.LightGray); Section("Continue ouvindo", stations.take(2), onPlay, favorites); DiscoverSection(onPlay); Section("Rádios em alta", stations, onPlay, favorites); Section("Perto de você", stations.filter { it.city.contains("Montes") || it.city.contains("Brasil") }, onPlay, favorites) }
@Composable fun DiscoverSection(onPlay: (Int) -> Unit) {
    Text("Descubra", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 22.dp, bottom = 10.dp))
    LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        item { DiscoverCard("Explorar rádios", "Encontre estações do Brasil e do mundo", Turquoise) { onPlay(0) } }
        item { DiscoverCard("Buscar artistas", "Veja rádios que tocam seu artista", Coral) { onPlay(2) } }
        item { DiscoverCard("Compartilhar", "Convide seus amigos para ouvir", Gold) { } }
    }
}
@Composable fun DiscoverCard(title: String, subtitle: String, color: Color, onClick: () -> Unit) {
    Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = color), modifier = Modifier.width(150.dp).height(138.dp).clickable { onClick() }) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.SpaceBetween) { Icon(Icons.Default.Explore, null, tint = Navy, modifier = Modifier.size(30.dp)); Text(title, color = Navy, fontWeight = FontWeight.Bold, fontSize = 16.sp); Text(subtitle, color = Navy.copy(alpha = 0.85f), fontSize = 12.sp) } }
}
@Composable fun SearchScreen(query: String, onQuery: (String) -> Unit, results: List<Station>, onPlay: (Station) -> Unit, favorites: MutableList<String>, title: String = "Pesquisar") { Text(title, color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 24.dp, bottom = 12.dp)); if (title == "Pesquisar") OutlinedTextField(value = query, onValueChange = onQuery, modifier = Modifier.fillMaxWidth(), placeholder = { Text("Rádio, artista, frequência, gênero ou cidade") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true); LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(vertical = 16.dp)) { items(results) { station -> StationRow(station, { onPlay(station) }, favorites) } } }
@Composable fun Section(title: String, list: List<Station>, onPlay: (Int) -> Unit, favorites: MutableList<String>) { Text(title, color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 22.dp, bottom = 10.dp)); LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) { items(list) { station -> Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color.Transparent), modifier = Modifier.width(150.dp).height(138.dp).background(Brush.verticalGradient(listOf(station.color, station.color.copy(alpha = 0.55f))), RoundedCornerShape(20.dp)).clickable { onPlay(stations.indexOf(station)) }) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.SpaceBetween) { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) { Icon(Icons.Default.GraphicEq, "Rádio", tint = Navy.copy(alpha = 0.65f), modifier = Modifier.size(30.dp)) }; Text(station.name, fontWeight = FontWeight.Bold, color = Navy, fontSize = 16.sp); Text(station.genre + " • " + station.city, color = Navy.copy(alpha = 0.85f), fontSize = 12.sp); Icon(Icons.Default.PlayCircle, "Tocar", tint = Navy, modifier = Modifier.size(30.dp)) } } } } }
@Composable fun StationRow(station: Station, onPlay: () -> Unit, favorites: MutableList<String>) { val fav = favorites.contains(station.name); Row(Modifier.fillMaxWidth().background(Color(0xFF102B40), RoundedCornerShape(14.dp)).clickable { onPlay() }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(52.dp).background(station.color, RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) { if (station.logoUrl.isNotBlank()) AsyncImage(model = station.logoUrl, contentDescription = station.name, modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(12.dp))) else Icon(Icons.Default.GraphicEq, null, tint = Navy) }; Column(Modifier.weight(1f).padding(horizontal = 12.dp)) { Text(station.name, color = Color.White, fontWeight = FontWeight.Bold); Text("${station.genre} • ${station.city}${if (station.frequency.isNotBlank()) " • ${station.frequency}" else ""}", color = Color.LightGray, fontSize = 12.sp) }; IconButton(onClick = { if (fav) favorites.remove(station.name) else favorites.add(station.name) }) { Icon(if (fav) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null, tint = Coral) } } }
@Composable fun MiniPlayer(station: Station, playing: Boolean, toggle: () -> Unit, remoteTitle: String? = null, remoteGenre: String? = null, previous: () -> Unit, next: () -> Unit) { Row(Modifier.fillMaxWidth().background(Color(0xFF102B40)).padding(horizontal = 14.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text(remoteTitle ?: station.name, color = Color.White, fontWeight = FontWeight.Bold); Text("${remoteGenre ?: station.genre} • ao vivo", color = Turquoise, fontSize = 12.sp) }; IconButton(onClick = previous) { Icon(Icons.Default.SkipPrevious, "Rádio anterior", tint = Color.White) }; IconButton(onClick = toggle) { Icon(if (playing) Icons.Default.PauseCircle else Icons.Default.PlayCircle, "Reproduzir", tint = Turquoise, modifier = Modifier.size(34.dp)) }; IconButton(onClick = next) { Icon(Icons.Default.SkipNext, "Próxima rádio", tint = Color.White) } } }
@Composable fun Profile(loggedIn: Boolean, onCreateAccount: () -> Unit) {
    var name by remember { mutableStateOf("") }; var email by remember { mutableStateOf("") }; var password by remember { mutableStateOf("") }
    Text("Perfil", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 24.dp))
    if (!loggedIn) {
        Text("Crie sua conta para salvar favoritos, histórico e recomendações.", color = Color.LightGray, modifier = Modifier.padding(top = 12.dp))
        OutlinedTextField(value = name, onValueChange = { name = it }, modifier = Modifier.fillMaxWidth().padding(top = 18.dp), placeholder = { Text("Seu nome") }, singleLine = true)
        OutlinedTextField(value = email, onValueChange = { email = it }, modifier = Modifier.fillMaxWidth().padding(top = 10.dp), placeholder = { Text("Seu e-mail") }, singleLine = true)
        OutlinedTextField(value = password, onValueChange = { password = it }, modifier = Modifier.fillMaxWidth().padding(top = 10.dp), placeholder = { Text("Senha") }, singleLine = true)
        Button(onClick = onCreateAccount, enabled = name.isNotBlank() && email.contains("@") && password.length >= 6, colors = ButtonDefaults.buttonColors(containerColor = Turquoise), modifier = Modifier.padding(top = 16.dp)) { Text("Criar minha conta", color = Navy) }
        Text("O cadastro online será conectado ao servidor na próxima etapa.", color = Color.Gray, fontSize = 12.sp, modifier = Modifier.padding(top = 12.dp))
    } else {
        var notifications by remember { mutableStateOf(true) }; var mobileData by remember { mutableStateOf(false) }
        Text("Conta criada", color = Turquoise, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 18.dp))
        Text("Seus favoritos, histórico e recomendações aparecerão aqui.", color = Color.LightGray, modifier = Modifier.padding(top = 8.dp))
        Text("Configurações", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 24.dp, bottom = 8.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Text("Notificações", color = Color.White, modifier = Modifier.weight(1f)); Switch(checked = notifications, onCheckedChange = { notifications = it }) }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Text("Permitir dados móveis", color = Color.White, modifier = Modifier.weight(1f)); Switch(checked = mobileData, onCheckedChange = { mobileData = it }) }
    }
}
