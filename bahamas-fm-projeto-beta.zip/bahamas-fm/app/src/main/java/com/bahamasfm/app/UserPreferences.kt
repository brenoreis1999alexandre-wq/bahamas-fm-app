package com.bahamasfm.app

import android.content.Context

/** Persistência local da beta; será migrada para banco do usuário quando o cadastro entrar. */
class UserPreferences(context: Context) {
    private val prefs = context.getSharedPreferences("bahamas_fm_user", Context.MODE_PRIVATE)
    fun favorites(): Set<String> = prefs.getStringSet("favorites", emptySet()) ?: emptySet()
    fun saveFavorites(values: Set<String>) { prefs.edit().putStringSet("favorites", values).apply() }
    fun history(): List<String> = prefs.getString("history", "")!!.split("\n").filter { it.isNotBlank() }
    fun addHistory(name: String) { val updated = (listOf(name) + history().filter { it != name }).take(30); prefs.edit().putString("history", updated.joinToString("\n")).apply() }
    fun name(): String = prefs.getString("user_name", "") ?: ""
    fun saveName(name: String) { prefs.edit().putString("user_name", name.trim()).apply() }
}
