package com.bahamasfm.app

import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

/** Controla o serviço de áudio, permitindo tocar com o app em segundo plano. */
class RadioPlayer(context: Context) {
    private val appContext = context.applicationContext

    fun play(streamUrl: String, title: String = "Bahamas FM", logoUrl: String = "") {
        val intent = Intent(appContext, RadioPlaybackService::class.java).apply {
            action = RadioPlaybackService.ACTION_PLAY
            putExtra(RadioPlaybackService.EXTRA_URL, streamUrl)
            putExtra(RadioPlaybackService.EXTRA_TITLE, title)
            putExtra(RadioPlaybackService.EXTRA_LOGO, logoUrl)
        }
        ContextCompat.startForegroundService(appContext, intent)
    }

    fun pause() {
        appContext.startService(Intent(appContext, RadioPlaybackService::class.java).setAction(RadioPlaybackService.ACTION_PAUSE))
    }

    fun release() {
        // Não encerra o serviço: sair da tela não deve interromper a rádio.
    }
}
