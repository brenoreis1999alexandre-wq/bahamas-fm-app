package com.bahamasfm.app

import android.content.Context
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer

/** Player preparado para streams reais; a URL só é tocada depois de validada pelo catálogo. */
class RadioPlayer(context: Context) {
    private val player = ExoPlayer.Builder(context).build()
    fun play(streamUrl: String) { player.setMediaItem(MediaItem.fromUri(streamUrl)); player.prepare(); player.play() }
    fun pause() = player.pause()
    fun release() = player.release()
}
