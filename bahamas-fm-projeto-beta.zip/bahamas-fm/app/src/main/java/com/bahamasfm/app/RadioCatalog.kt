package com.bahamasfm.app

import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL

/** Catálogo inicial usando a rede pública Radio Browser. Depois ele será complementado pelo painel Bahamas FM. */
data class CatalogRadio(val name: String, val streamUrl: String, val genre: String, val city: String, val state: String, val country: String, val favicon: String)

object RadioCatalog {
    fun search(query: String = "", countryCode: String = "BR", state: String = "", city: String = "", limit: Int = 50): List<CatalogRadio> {
        val endpoint = "https://de1.api.radio-browser.info/json/stations/search?countrycode=$countryCode&limit=$limit&order=clickcount&reverse=true&hidebroken=true&name=${java.net.URLEncoder.encode(query, \"UTF-8\")}"
        val connection = URL(endpoint).openConnection() as HttpURLConnection
        connection.requestMethod = "GET"; connection.connectTimeout = 8000; connection.readTimeout = 8000
        return try {
            val body = connection.inputStream.bufferedReader().use { it.readText() }
            val json = JSONArray(body); buildList {
                for (i in 0 until json.length()) {
                    val item = json.getJSONObject(i); val stream = item.optString("url_resolved").ifBlank { item.optString("url") }
                    if (stream.isNotBlank()) add(CatalogRadio(item.optString("name"), stream, item.optString("tags"), item.optString("state"), item.optString("state"), item.optString("country"), item.optString("favicon")))
                }
            }
        } finally { connection.disconnect() }
    }
}
