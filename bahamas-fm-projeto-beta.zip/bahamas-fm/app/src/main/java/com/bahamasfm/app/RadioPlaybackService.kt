package com.bahamasfm.app

import android.content.Intent
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

/** Player persistente: continua tocando mesmo quando a tela do app é fechada. */
class RadioPlaybackService : MediaSessionService() {
    private lateinit var player: ExoPlayer
    private lateinit var mediaSession: MediaSession

    override fun onCreate() {
        super.onCreate()
        player = ExoPlayer.Builder(this).build()
        mediaSession = MediaSession.Builder(this, player).build()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_PLAY -> {
                val url = intent.getStringExtra(EXTRA_URL)
                if (!url.isNullOrBlank()) {
                    val title = intent.getStringExtra(EXTRA_TITLE) ?: "Bahamas FM"
                    val item = MediaItem.Builder()
                        .setUri(url)
                        .setMediaMetadata(MediaMetadata.Builder().setTitle(title).setArtist("Bahamas FM").build())
                        .build()
                    player.setMediaItem(item)
                    player.prepare()
                    player.play()
                }
            }
            ACTION_PAUSE -> player.pause()
            ACTION_STOP -> player.stop()
        }
        return START_STICKY
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession = mediaSession

    override fun onDestroy() {
        mediaSession.release()
        player.release()
        super.onDestroy()
    }

    companion object {
        const val ACTION_PLAY = "com.bahamasfm.app.PLAY"
        const val ACTION_PAUSE = "com.bahamasfm.app.PAUSE"
        const val ACTION_STOP = "com.bahamasfm.app.STOP"
        const val EXTRA_URL = "stream_url"
        const val EXTRA_TITLE = "station_title"
    }
}
