package com.bahamasfm.app

import android.content.Intent
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

/** Sessão de mídia do Android: aparece na tela bloqueada, painel de mídia e Bluetooth do carro. */
class RadioPlaybackService : MediaSessionService() {
    private lateinit var player: ExoPlayer
    private lateinit var mediaSession: MediaSession
    private var stationTitle = "Bahamas FM"
    private var stationLogo = ""

    override fun onCreate() {
        super.onCreate()
        val audioAttributes = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
            .build()
        player = ExoPlayer.Builder(this).setAudioAttributes(audioAttributes, true).build()
        player.setHandleAudioBecomingNoisy(true)
        mediaSession = MediaSession.Builder(this, player).build()
        player.addListener(object : Player.Listener {
            override fun onMediaMetadataChanged(metadata: MediaMetadata) {
                sendBroadcast(Intent(ACTION_METADATA).apply {
                    putExtra(EXTRA_ARTIST, metadata.artist?.toString().orEmpty())
                    putExtra(EXTRA_SONG, metadata.title?.toString().orEmpty())
                })
            }
        })
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_PLAY -> {
                val url = intent.getStringExtra(EXTRA_URL).orEmpty()
                stationTitle = intent.getStringExtra(EXTRA_TITLE) ?: "Bahamas FM"
                stationLogo = intent.getStringExtra(EXTRA_LOGO).orEmpty()
                if (url.isNotBlank()) {
                    val metadata = MediaMetadata.Builder()
                        .setTitle(stationTitle)
                        .setArtist("Bahamas FM")
                        .apply { if (stationLogo.isNotBlank()) setArtworkUri(android.net.Uri.parse(stationLogo)) }
                        .build()
                    player.setMediaItem(MediaItem.Builder().setUri(url).setMediaMetadata(metadata).build())
                    player.prepare()
                    player.play()
                } else if (player.mediaItemCount > 0) {
                    player.play()
                }
            }
            ACTION_PAUSE -> player.pause()
            ACTION_STOP -> {
                player.stop()
                stopSelf()
            }
        }
        return START_STICKY
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession = mediaSession

    override fun onDestroy() {
        mediaSession.release()
        player.release()
        super.onDestroy()
    }

    companion object {
        const val ACTION_PLAY = "com.bahamasfm.app.PLAY"
        const val ACTION_PAUSE = "com.bahamasfm.app.PAUSE"
        const val ACTION_STOP = "com.bahamasfm.app.STOP"
        const val EXTRA_URL = "stream_url"
        const val EXTRA_TITLE = "station_title"
        const val EXTRA_LOGO = "station_logo"
        const val ACTION_METADATA = "com.bahamasfm.app.METADATA"
        const val EXTRA_ARTIST = "artist"
        const val EXTRA_SONG = "song"
    }
}
