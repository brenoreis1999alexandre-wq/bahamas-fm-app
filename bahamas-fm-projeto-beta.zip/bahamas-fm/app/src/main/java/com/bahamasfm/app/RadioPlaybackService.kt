package com.bahamasfm.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import java.net.URL

/** Serviço de áudio estável em segundo plano, com controle na notificação. */
class RadioPlaybackService : Service() {
    private lateinit var player: ExoPlayer
    private lateinit var mediaSession: MediaSession
    private var stationTitle = "Bahamas FM"
    private var currentUrl = ""
    private var logo: Bitmap? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        val attrs = AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build()
        player = ExoPlayer.Builder(this).setAudioAttributes(attrs, true).build()
        player.setHandleAudioBecomingNoisy(true)
        mediaSession = MediaSession.Builder(this, player).build()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_PLAY -> {
                val url = intent.getStringExtra(EXTRA_URL).orEmpty()
                stationTitle = intent.getStringExtra(EXTRA_TITLE) ?: stationTitle
                val logoUrl = intent.getStringExtra(EXTRA_LOGO).orEmpty()
                startForeground(NOTIFICATION_ID, notification())
                if (logoUrl.isNotBlank()) Thread { runCatching { BitmapFactory.decodeStream(URL(logoUrl).openStream()) }.onSuccess { logo = it; refresh() } }.start()
                if (url.isNotBlank()) {
                    currentUrl = url
                    val metadata = androidx.media3.common.MediaMetadata.Builder()
                        .setTitle(stationTitle)
                        .setArtist("Bahamas FM")
                        .apply { if (logoUrl.isNotBlank()) setArtworkUri(android.net.Uri.parse(logoUrl)) }
                        .build()
                    player.setMediaItem(MediaItem.Builder().setUri(url).setMediaMetadata(metadata).build())
                    player.prepare()
                    player.play()
                } else if (player.mediaItemCount > 0) player.play()
                refresh()
            }
            ACTION_PAUSE -> { player.pause(); refresh() }
            ACTION_STOP -> { player.stop(); stopSelf() }
        }
        return START_STICKY
    }

    private fun notification(): Notification {
        val playing = player.isPlaying
        val toggle = if (playing) ACTION_PAUSE else ACTION_PLAY
        val toggleLabel = if (playing) "Pausar" else "Continuar"
        val toggleIcon = if (playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
        val toggleIntent = PendingIntent.getService(this, 10, Intent(this, RadioPlaybackService::class.java).setAction(toggle).putExtra(EXTRA_URL, ""), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val stopIntent = PendingIntent.getService(this, 11, Intent(this, RadioPlaybackService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setLargeIcon(logo)
            .setContentTitle(stationTitle)
            .setContentText(if (playing) "Tocando no Bahamas FM" else "Rádio pausada")
            .setOngoing(playing)
            .setOnlyAlertOnce(true)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setCategory(NotificationCompat.CATEGORY_TRANSPORT)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .addAction(toggleIcon, toggleLabel, toggleIntent)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Parar", stopIntent)
            .build()
    }

    private fun refresh() { NotificationManagerCompat.from(this).notify(NOTIFICATION_ID, notification()) }
    private fun createNotificationChannel() { if (Build.VERSION.SDK_INT >= 26) getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel(CHANNEL_ID, "Rádio Bahamas FM", NotificationManager.IMPORTANCE_LOW)) }
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onDestroy() { mediaSession.release(); player.release(); super.onDestroy() }

    companion object {
        const val ACTION_PLAY = "com.bahamasfm.app.PLAY"
        const val ACTION_PAUSE = "com.bahamasfm.app.PAUSE"
        const val ACTION_STOP = "com.bahamasfm.app.STOP"
        const val EXTRA_URL = "stream_url"
        const val EXTRA_TITLE = "station_title"
        const val EXTRA_LOGO = "station_logo"
        const val ACTION_METADATA = "com.bahamasfm.app.METADATA"
        const val EXTRA_ARTIST = "artist"
        const val EXTRA_SONG = "song"
        private const val CHANNEL_ID = "bahamas_fm_playback"
        private const val NOTIFICATION_ID = 1001
    }
}
