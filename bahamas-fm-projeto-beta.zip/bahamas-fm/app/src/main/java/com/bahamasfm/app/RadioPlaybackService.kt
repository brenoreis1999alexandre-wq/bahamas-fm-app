package com.bahamasfm.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer

/** Serviço foreground de áudio: a rádio continua tocando fora da tela do app. */
class RadioPlaybackService : Service() {
    private lateinit var player: ExoPlayer
    private var stationTitle = "Bahamas FM"

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        player = ExoPlayer.Builder(this).build()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_PLAY -> {
                val url = intent.getStringExtra(EXTRA_URL)
                stationTitle = intent.getStringExtra(EXTRA_TITLE) ?: "Bahamas FM"
                startForeground(NOTIFICATION_ID, notification())
                if (!url.isNullOrBlank()) {
                    player.setMediaItem(MediaItem.fromUri(url))
                    player.prepare()
                    player.play()
                }
            }
            ACTION_PAUSE -> player.pause()
            ACTION_STOP -> stopSelf()
            else -> startForeground(NOTIFICATION_ID, notification())
        }
        return START_STICKY
    }

    private fun notification(): Notification = NotificationCompat.Builder(this, CHANNEL_ID)
        .setSmallIcon(android.R.drawable.ic_media_play)
        .setContentTitle(stationTitle)
        .setContentText("Tocando no Bahamas FM")
        .setOngoing(true)
        .setCategory(NotificationCompat.CATEGORY_SERVICE)
        .setPriority(NotificationCompat.PRIORITY_LOW)
        .build()

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Rádio Bahamas FM", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        player.release()
        super.onDestroy()
    }

    companion object {
        const val ACTION_PLAY = "com.bahamasfm.app.PLAY"
        const val ACTION_PAUSE = "com.bahamasfm.app.PAUSE"
        const val ACTION_STOP = "com.bahamasfm.app.STOP"
        const val EXTRA_URL = "stream_url"
        const val EXTRA_TITLE = "station_title"
        private const val CHANNEL_ID = "bahamas_fm_playback"
        private const val NOTIFICATION_ID = 1001
    }
}
