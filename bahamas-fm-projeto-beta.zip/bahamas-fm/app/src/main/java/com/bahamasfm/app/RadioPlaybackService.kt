package com.bahamasfm.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.app.PendingIntent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import java.net.URL
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.media3.common.C
import androidx.media3.common.AudioAttributes
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer

/** Serviço foreground de áudio: a rádio continua tocando fora da tela do app. */
class RadioPlaybackService : Service() {
    private lateinit var player: ExoPlayer
    private var stationTitle = "Bahamas FM"
    private var currentStreamUrl = ""
    private var currentSong = ""
    private var currentArtist = ""
    private var stationLogo: Bitmap? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        val audioAttributes = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
            .build()
        player = ExoPlayer.Builder(this).setAudioAttributes(audioAttributes, true).build()
        player.setHandleAudioBecomingNoisy(true)
        player.addListener(object : Player.Listener {
            override fun onMediaMetadataChanged(metadata: MediaMetadata) {
                currentArtist = metadata.artist?.toString().orEmpty()
                currentSong = metadata.title?.toString().orEmpty()
                sendBroadcast(Intent(ACTION_METADATA).apply {
                    putExtra(EXTRA_ARTIST, currentArtist)
                    putExtra(EXTRA_SONG, currentSong)
                })
                if (::player.isInitialized) refreshNotification()
            }
        })
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_PLAY -> {
                val url = intent.getStringExtra(EXTRA_URL).orEmpty()
                stationTitle = intent.getStringExtra(EXTRA_TITLE) ?: stationTitle
                stationLogo = null
                val logoUrl = intent.getStringExtra(EXTRA_LOGO).orEmpty()
                if (logoUrl.isNotBlank()) Thread { runCatching { BitmapFactory.decodeStream(URL(logoUrl).openStream()) }.onSuccess { stationLogo = it; if (::player.isInitialized) refreshNotification() } }.start()
                startForeground(NOTIFICATION_ID, notification())
                if (url.isBlank() && currentStreamUrl.isNotBlank()) {
                    player.play()
                } else if (url.isNotBlank()) {
                    currentStreamUrl = url
                    player.setMediaItem(MediaItem.fromUri(url))
                    player.prepare()
                    player.play()
                }
                refreshNotification()
            }
            ACTION_PAUSE -> { player.pause(); refreshNotification() }
            ACTION_STOP -> stopSelf()
            else -> startForeground(NOTIFICATION_ID, notification())
        }
        return START_STICKY
    }

    private fun notification(): Notification {
        val action = if (player.isPlaying) ACTION_PAUSE else ACTION_PLAY
        val label = if (player.isPlaying) "Pausar" else "Continuar"
        val icon = if (player.isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
        val toggleIntent = PendingIntent.getService(this, 10, Intent(this, RadioPlaybackService::class.java).setAction(action), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val stopIntent = PendingIntent.getService(this, 11, Intent(this, RadioPlaybackService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setLargeIcon(stationLogo)
            .setContentTitle(if (currentSong.isNotBlank()) currentSong else stationTitle)
            .setContentText(if (currentArtist.isNotBlank()) currentArtist else if (player.isPlaying) "Tocando no Bahamas FM" else "Rádio pausada")
            .setOngoing(player.isPlaying)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setCategory(NotificationCompat.CATEGORY_TRANSPORT)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .addAction(icon, label, toggleIntent)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Parar", stopIntent)
            .build()
    }

    private fun refreshNotification() {
        NotificationManagerCompat.from(this).notify(NOTIFICATION_ID, notification())
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Rádio Bahamas FM", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        player.release()
        super.onDestroy()
    }

    companion object {
        const val ACTION_PLAY = "com.bahamasfm.app.PLAY"
        const val ACTION_PAUSE = "com.bahamasfm.app.PAUSE"
        const val ACTION_STOP = "com.bahamasfm.app.STOP"
        const val EXTRA_URL = "stream_url"
        const val EXTRA_TITLE = "station_title"
        const val EXTRA_LOGO = "station_logo"
        const val ACTION_METADATA = "com.bahamasfm.app.METADATA"
        const val EXTRA_ARTIST = "artist"
        const val EXTRA_SONG = "song"
        private const val CHANNEL_ID = "bahamas_fm_playback"
        private const val NOTIFICATION_ID = 1001
    }
}
