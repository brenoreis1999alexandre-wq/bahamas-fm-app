package com.bahamasfm.app

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class CatalogViewModel : ViewModel() {
    private val _radios = MutableStateFlow<List<CatalogRadio>>(emptyList())
    val radios: StateFlow<List<CatalogRadio>> = _radios.asStateFlow()
    private val _loading = MutableStateFlow(false)
    val loading: StateFlow<Boolean> = _loading.asStateFlow()
    fun search(query: String = "", countryCode: String = "BR", state: String = "", city: String = "") {
        viewModelScope.launch(Dispatchers.IO) { _loading.value = true; runCatching { val online = runCatching { OnlineCatalog.load() }.getOrDefault(emptyList()); val public = runCatching { RadioCatalog.search(query, countryCode, state, city) }.getOrDefault(emptyList()); (online + public).filter { query.isBlank() || listOf(it.name, it.genre, it.city, it.state, it.country).any { value -> searchable(value).contains(searchable(query)) } }.filter { val selected = countryCode.replace("🇧🇷", "").replace("🌎", "").trim(); selected.isBlank() || ((selected.equals("BR", true) || selected.equals("Brasil", true) || selected.equals("Brazil", true)) && (it.country.equals("Brasil", true) || it.country.equals("Brazil", true))) || (selected.equals("WORLD", true) && !it.country.equals("Brasil", true) && !it.country.equals("Brazil", true)) }.filter { val selected = state.trim(); selected.isBlank() || it.state.contains(selected, true) }.filter { val selected = city.trim(); selected.isBlank() || it.city.contains(selected, true) }.distinctBy { it.streamUrl } }.onSuccess { _radios.value = it }.also { _loading.value = false } }
    }
}

private fun searchable(value: String): String = java.text.Normalizer.normalize(value.lowercase(), java.text.Normalizer.Form.NFD).replace("\\p{M}".toRegex(), "").filter { it.isLetterOrDigit() }
