package com.bahamasfm.app

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class CatalogViewModel : ViewModel() {
    private val _radios = MutableStateFlow<List<CatalogRadio>>(emptyList())
    val radios: StateFlow<List<CatalogRadio>> = _radios.asStateFlow()
    private val _loading = MutableStateFlow(false)
    val loading: StateFlow<Boolean> = _loading.asStateFlow()
    fun search(query: String = "", countryCode: String = "BR", state: String = "", city: String = "") {
        viewModelScope.launch(Dispatchers.IO) { _loading.value = true; runCatching { val online = OnlineCatalog.load(); val public = RadioCatalog.search(query, countryCode, state, city); (online + public).filter { query.isBlank() || listOf(it.name, it.genre, it.city, it.state, it.country).any { value -> value.contains(query, true) } }.filter { countryCode.isBlank() || it.country.equals("Brasil", true) || it.country.equals("Brazil", true) }.filter { state.isBlank() || it.state.contains(state, true) }.filter { city.isBlank() || it.city.contains(city, true) }.distinctBy { it.streamUrl } }.onSuccess { _radios.value = it }.also { _loading.value = false } }
    }
}
