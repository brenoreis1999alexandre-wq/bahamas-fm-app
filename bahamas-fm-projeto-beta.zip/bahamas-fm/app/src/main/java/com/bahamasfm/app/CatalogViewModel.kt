package com.bahamasfm.app

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class CatalogViewModel : ViewModel() {
    private val _radios = MutableStateFlow<List<CatalogRadio>>(emptyList())
    val radios: StateFlow<List<CatalogRadio>> = _radios.asStateFlow()
    private val _loading = MutableStateFlow(false)
    val loading: StateFlow<Boolean> = _loading.asStateFlow()
    fun search(query: String = "", countryCode: String = "BR", state: String = "", city: String = "") {
        viewModelScope.launch(Dispatchers.IO) {
            _loading.value = true
            try {
                // O catálogo remoto é opcional: se o GitHub estiver fora do ar,
                // a tela volta a usar o catálogo público/local em vez de travar.
                val online = runCatching { OnlineCatalog.load() }.getOrDefault(emptyList())
                val public = RadioCatalog.search(query, countryCode, state, city)
                val all = online + public
                val selectedCountry = countryCode.replace("🇧🇷", "").replace("🌎", "").trim()
                val filtered = all
                    .filter { query.isBlank() || listOf(it.name, it.genre, it.city, it.state, it.country).any { value -> searchable(value).contains(searchable(query)) } }
                    .filter {
                        selectedCountry.isBlank() ||
                            (selectedCountry.equals("BR", true) || selectedCountry.equals("Brasil", true) || selectedCountry.equals("Brazil", true)) &&
                            (it.country.equals("Brasil", true) || it.country.equals("Brazil", true))
                    }
                    .filter { state.isBlank() || it.state.contains(state.trim(), true) }
                    .filter { city.isBlank() || it.city.contains(city.trim(), true) }
                    .filter { it.streamUrl.isNotBlank() }
                    .distinctBy { it.streamUrl }
                _radios.value = filtered
            } finally {
                _loading.value = false
            }
        }
    }
}

private fun searchable(value: String): String = java.text.Normalizer.normalize(value.lowercase(), java.text.Normalizer.Form.NFD).replace("\\p{M}".toRegex(), "").filter { it.isLetterOrDigit() }
