package com.bahamasfm.app

object BrazilRegions {
    val states = listOf("Acre", "Alagoas", "Amapá", "Amazonas", "Bahia", "Ceará", "Distrito Federal", "Espírito Santo", "Goiás", "Maranhão", "Mato Grosso", "Mato Grosso do Sul", "Minas Gerais", "Pará", "Paraíba", "Paraná", "Pernambuco", "Piauí", "Rio de Janeiro", "Rio Grande do Norte", "Rio Grande do Sul", "Rondônia", "Roraima", "Santa Catarina", "São Paulo", "Sergipe", "Tocantins")
    val featuredCities = mapOf("Minas Gerais" to listOf("Montes Claros", "Janaúba", "Belo Horizonte", "Uberlândia", "Juiz de Fora"), "São Paulo" to listOf("São Paulo", "Campinas", "Santos", "Ribeirão Preto"), "Rio de Janeiro" to listOf("Rio de Janeiro", "Niterói", "Petrópolis"), "Bahia" to listOf("Salvador", "Feira de Santana", "Vitória da Conquista"))
}
