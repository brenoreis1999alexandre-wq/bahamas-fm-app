# Regiões

A seleção de estado e cidade foi preparada com todos os estados brasileiros. A lista inicial de cidades destaca Montes Claros, Janaúba e outras cidades importantes; o catálogo remoto continuará permitindo qualquer cidade encontrada.
