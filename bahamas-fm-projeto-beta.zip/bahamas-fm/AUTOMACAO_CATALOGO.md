# Catálogo automático

O aplicativo consulta o catálogo público do GitHub ao pesquisar rádios. O arquivo remoto é `radios.json`; mudanças nesse arquivo aparecem no app sem atualização da loja.

O catálogo aplica automaticamente a regra de não exibir gênero gospel. Se o catálogo remoto estiver vazio ou indisponível, a busca usa a fonte pública de rádios como fallback.
